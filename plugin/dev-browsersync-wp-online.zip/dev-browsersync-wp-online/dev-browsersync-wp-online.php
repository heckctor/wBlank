<?php
/**
 * Plugin Name: BrowserSync WP Online
 * Plugin URI: http://www.franzarmas.com
 * Description: Activar <code>SOLAMENTE</code> cuando necesitamos utilizar Browser-Sync para sincronizar los archivos almacenados localmente con un WP Online (no localhost).
 * Author: Franz Armas
 * Author URI: http://www.franzarmas.com
 * Version: 1.0
 * License: GPL
**/

// No permitir acceso directamente desde la URL
if ( ! defined( 'ABSPATH' ) ) exit;


/*==============================================
=           CONFIGURACION DEL PLUGIN           =
==============================================*/

/* Ingrese la URL Local de Browser-Sync, ej: http://localhost:3000 */
$localBrowserSync = "http://localhost:7777";

/*
 * Todos los $handle de los styles o scripts que fueron registrados a través de
 * 'wp_register_style()' - 'wp_enqueue_style()' - 'wp_register_script()' ó 'wp_enqueue_script()';
 * y que <COMIENCEN> con alguna de las palabras agregadas en el array ($patronComienzo) serán sincronizados con BrowserSync.
 */
$patronComienzo = ['wblank-']; // Array

/*====  Fin de: CONFIGURACION DEL PLUGIN  ====*/




// Aqui comienza la magia :)
add_action('init', 'fa_browsersync');
function fa_browsersync(){
    global $patronComienzo;

    // Si estamos conectados con un usuario que pueda actualizar el core de WP, comunmente rol 'Administrador'.
    if ( !is_admin() && is_user_logged_in() && current_user_can('update_core') && empty($patronComienzo) == false ) {
        /**
         * Agregar script de BrowserSync en nuestro sitio.
         */
        add_action( 'wp_head', 'fa_browsersync_script', 99999 );
        function fa_browsersync_script() {
            global $localBrowserSync;

            $portBrowserSync = preg_replace('/[^0-9]+/', '', $localBrowserSync);

            ?>
            <script id="__bs_script__">//<![CDATA[
                document.write("<script async src='http://localhost:<?php echo $portBrowserSync; ?>/browser-sync/browser-sync-client.js'><\/script>".replace("HOST", location.hostname));
            //]]></script>
            <?php
        }


        /**
         * Cambiar Path para styles y scripts.
         */
        add_filter( 'script_loader_src', 'fa_change_path_browsersync', 15, 2);
        add_filter( 'style_loader_src', 'fa_change_path_browsersync', 15, 2);
        function fa_change_path_browsersync($src, $handle){
            global $localBrowserSync;
            global $wp_styles;
            global $wp_scripts;

            // Array con los handles de los styles que serán sincronizados por BS.
            $handleStylesSync = array_filter($wp_styles->queue, function ($el) { 
                global $patronComienzo;
                
                foreach ($patronComienzo as $value){
                    if (strpos($el, $value) === 0) {
                        return $el;
                    }
                }
            });

            // Array con los handles de los scripts que serán sincronizados por BS.
            $handleScriptsSync = array_filter($wp_scripts->queue, function ($el) { 
                global $patronComienzo;
                
                foreach ($patronComienzo as $value){
                    if (strpos($el, $value) === 0) {
                        return $el;
                    }
                }
            });

            // Cambiar path para styles
            if ( in_array($handle, $handleStylesSync) ) {
                $path = str_replace( get_stylesheet_directory_uri(), trim($localBrowserSync), $src);
                return $path;
            }

            // Cambiar path para scripts
            if ( in_array($handle, $handleScriptsSync) ) {
                $path = str_replace( get_stylesheet_directory_uri(), trim($localBrowserSync), $src);
                return $path;
            }
            
            return $src;
        }

        /**
         * Agregar Notificacion en frontend.
         */
        add_action( 'wp_footer', 'fa_notify_plg_active' );
        function fa_notify_plg_active(){
            ?>
            <div style="box-sizing: border-box;position:fixed;top:50%;z-index:9999999999;background:#fff;width:150px;height:70px;margin-top:-35px;padding:10px;border-radius:0 10px 10px 0;box-shadow:0 0 10px 0 rgba(0,0,0,.5);font-family:sans-serif;font-size:.7em;line-height:1.2em;text-align:center">Estas utilizando <strong>BrowserSync WP Online</strong> no olvides desactivarlo al terminar de editar</div>
            <?php
        }
    }
}